# project3-group-16
project3-group-16 created by GitHub Classroom
To Do:
- Make keyboard disappear when return is pressed (George)
- Make level, collectable and player objects (Alex)
- Send data from options to player and level (George)
- Design level themes (Gary)
- Learn SpriteKit (Everyone)
- Prototype of actual gameplay (Everyone)
- Save and load highscore data (Alex)
- Hook up all sliders with value labels (George)
- Images for help screen (Gary)
- Create presentation (Everyone)
- Record finished/final prototype (Everyone)
