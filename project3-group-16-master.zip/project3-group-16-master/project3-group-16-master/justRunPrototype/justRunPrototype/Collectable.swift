//
//  Collectable.swift
//  justRunPrototype
//
//  Created by Alexander Leydon on 21/5/18.
//  Copyright © 2018 Alexander Leydon. All rights reserved.
//

import Foundation
import UIKit

class Collectable: Codable{
    var score: Double
    // var image: UIImage
    init(score: Double){
        self.score = score
    }
}
