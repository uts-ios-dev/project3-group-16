# project3-group-16
project3-group-16 created by GitHub Classroom
Update: game has changed from a temple run like game to
        a flappy bird like game.
        
To Do:
- Make keyboard disappear when return is pressed (Alex)
- Send data from options to player and level (Alex)
- Practice with SpriteKit (Everyone)
- Prototype of actual gameplay (Everyone)
- Create presentation (Everyone)
- Record finished/final prototype (Everyone)
